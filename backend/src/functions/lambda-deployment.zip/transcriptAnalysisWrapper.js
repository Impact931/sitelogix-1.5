/**
 * Full Analytics Extraction (Standalone JavaScript)
 * Extracts: personnel, hours/overtime, vendors, deliveries, constraints, delays, injuries
 */

const OpenAI = require('openai');
const { DynamoDBClient, UpdateItemCommand } = require('@aws-sdk/client-dynamodb');
const { marshall } = require('@aws-sdk/util-dynamodb');

const dynamoClient = new DynamoDBClient({});

/**
 * Convert transcript to plain text
 * Handles ElevenLabs Conversational AI API format
 */
function transcriptToText(transcript) {
  // Handle null or undefined
  if (!transcript) {
    console.warn('transcriptToText: transcript is null or undefined');
    return '';
  }

  // Handle pending/incomplete transcripts
  if (transcript.status === 'pending' || transcript.status === 'processing') {
    console.warn(`transcriptToText: transcript status is ${transcript.status}, not ready for processing`);
    return '';
  }

  // Handle ElevenLabs conversation object format
  if (transcript.transcript && Array.isArray(transcript.transcript)) {
    if (transcript.transcript.length === 0) {
      console.warn('transcriptToText: transcript array is empty');
      return '';
    }

    return transcript.transcript
      .map(msg => {
        const role = msg.role === 'user' ? 'Manager' : 'Roxy';
        // Handle both 'message' (standard) and 'multivoice_message' (advanced) formats
        const messageText = msg.message || (msg.multivoice_message?.parts?.map(p => p.text).join(' ')) || '';
        return `${role}: ${messageText}`;
      })
      .filter(line => line.trim().length > 0) // Remove empty messages
      .join('\n\n');
  }

  // If transcript is already a string, return it
  if (typeof transcript === 'string') {
    console.warn('transcriptToText: transcript is already a string, using as-is');
    return transcript;
  }

  // Fallback: try to extract any useful text from the object
  console.warn('transcriptToText: unexpected transcript format:', typeof transcript);
  console.warn('Transcript keys:', Object.keys(transcript));

  return '';
}

/**
 * Build extraction prompt for Claude
 */
function buildExtractionPrompt(rawTranscript, context) {
  return `You are an AI assistant specialized in extracting structured construction data from daily report conversations.

CONTEXT:
- Project: ${context.projectName}
- Location: ${context.projectLocation}
- Manager: ${context.managerName}
- Date: ${context.reportDate}

TRANSCRIPT:
${rawTranscript}

TASK:
Extract ALL of the following information in JSON format:

1. PERSONNEL:
For each person mentioned, extract:
- fullName: Full name (best guess)
- goByName: Nickname or "go by" name
- position: Position (Project Manager, Foreman, Journeyman, Apprentice)
- teamAssignment: Team (Project Manager, Team 1, Team 2, etc.)
- hoursWorked: Hours worked (number)
- overtimeHours: Overtime hours (number, default 0)
- healthStatus: Health status (Healthy, N/A, or specific limitation)
- activitiesPerformed: Brief description
- extractedFromText: Exact quote

2. WORK ACTIVITIES (workLogs):
For each team/group:
- teamId: Team identifier
- level: Building level or area
- personnelAssigned: Array of full names
- personnelCount: Number of personnel
- taskDescription: What they worked on
- hoursWorked: Total team hours
- overtimeHours: Total team overtime
- materialsUsed: Array of materials (optional)
- equipmentUsed: Array of equipment (optional)
- extractedFromText: Exact quote

3. CONSTRAINTS/ISSUES (constraints):
For each issue:
- category: delay, safety, material, weather, labor, coordination, other
- level: Building level
- severity: low, medium, high, critical
- title: Short title (1-5 words)
- description: Full description
- status: open, in_progress, resolved
- extractedFromText: Exact quote

4. VENDORS/DELIVERIES (vendors):
For each delivery:
- companyName: Company name
- vendorType: supplier, subcontractor, rental, other
- materialsDelivered: Description
- deliveryTime: Time if mentioned
- receivedBy: Person who received
- deliveryNotes: Issues or special notes
- extractedFromText: Exact quote

5. TIME SUMMARY (timeSummary):
- totalPersonnelCount: Total unique personnel
- totalRegularHours: Sum of regular hours
- totalOvertimeHours: Sum of overtime
- arrivalTime: Site arrival time
- departureTime: Site departure time

RULES:
- Include extractedFromText with direct quotes
- Use null for missing data
- Be conservative - only extract clearly stated info
- Use consistent naming
- For injuries, include in constraints with category "safety"

Return ONLY valid JSON:
{
  "personnel": [...],
  "workLogs": [...],
  "constraints": [...],
  "vendors": [...],
  "timeSummary": {...}
}`;
}

/**
 * Process transcript and extract all analytics data
 */
async function processTranscriptAnalytics(transcript, context) {
  try {
    console.log('📊 Starting full transcript analytics extraction...');

    const { reportId, projectId, projectName, projectLocation, managerName, reportDate } = context;

    // Convert transcript to text
    const rawTranscript = transcriptToText(transcript);

    if (!rawTranscript || rawTranscript.trim().length === 0) {
      throw new Error('Empty transcript');
    }

    // Build prompt
    const prompt = buildExtractionPrompt(rawTranscript, {
      projectName,
      projectLocation,
      managerName,
      reportDate
    });

    // Analyze with OpenAI GPT-4
    const openaiApiKey = process.env.OPENAI_API_KEY;
    if (!openaiApiKey) {
      throw new Error('OPENAI_API_KEY not configured');
    }

    const openai = new OpenAI({ apiKey: openaiApiKey });

    console.log('🤖 Analyzing transcript with GPT-4...');

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: 'You are an AI assistant specialized in extracting structured construction data from daily report conversations. Always respond with valid JSON only.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0,
      response_format: { type: 'json_object' }
    });

    const responseText = completion.choices[0].message.content;
    if (!responseText) {
      throw new Error('No response from GPT-4');
    }

    // Extract JSON from response
    let jsonText = responseText.trim();
    if (jsonText.startsWith('```json')) {
      jsonText = jsonText.replace(/```json\n/, '').replace(/\n```$/, '');
    } else if (jsonText.startsWith('```')) {
      jsonText = jsonText.replace(/```\n/, '').replace(/\n```$/, '');
    }

    const extractedData = JSON.parse(jsonText);

    console.log('✅ Transcript analysis complete:');
    console.log(`   - Personnel: ${extractedData.personnel?.length || 0}`);
    console.log(`   - Work Logs: ${extractedData.workLogs?.length || 0}`);
    console.log(`   - Constraints: ${extractedData.constraints?.length || 0}`);
    console.log(`   - Vendors: ${extractedData.vendors?.length || 0}`);

    // Calculate summary statistics from extracted data
    const totalPersonnel = extractedData.timeSummary?.totalPersonnelCount || 0;
    const totalRegularHours = extractedData.timeSummary?.totalRegularHours || 0;
    const totalOvertimeHours = extractedData.timeSummary?.totalOvertimeHours || 0;

    console.log(`📊 Summary: ${totalPersonnel} personnel, ${totalRegularHours} regular hrs, ${totalOvertimeHours} OT hrs`);

    // Update the report in DynamoDB with extracted data AND summary fields
    const updateCommand = new UpdateItemCommand({
      TableName: 'sitelogix-reports',
      Key: marshall({
        PK: `PROJECT#${projectId}`,
        SK: `REPORT#${reportDate}#${reportId}`
      }),
      UpdateExpression: `
        SET extracted_data = :extractedData,
            analytics_processed_at = :processedAt,
            analytics_status = :status,
            total_personnel = :totalPersonnel,
            total_regular_hours = :totalRegularHours,
            total_overtime_hours = :totalOvertimeHours
      `,
      ExpressionAttributeValues: marshall({
        ':extractedData': extractedData,
        ':processedAt': new Date().toISOString(),
        ':status': 'completed',
        ':totalPersonnel': totalPersonnel,
        ':totalRegularHours': totalRegularHours,
        ':totalOvertimeHours': totalOvertimeHours
      })
    });

    await dynamoClient.send(updateCommand);
    console.log('✅ Extracted analytics data saved to DynamoDB');

    return {
      success: true,
      extractedData
    };
  } catch (error) {
    console.error('❌ Transcript analytics extraction failed:', error);

    // Try to update report status to indicate analytics failed (non-fatal)
    try {
      const updateCommand = new UpdateItemCommand({
        TableName: 'sitelogix-reports',
        Key: marshall({
          PK: `PROJECT#${context.projectId}`,
          SK: `REPORT#${context.reportDate}#${context.reportId}`
        }),
        UpdateExpression: `
          SET analytics_status = :status,
              analytics_error = :error
        `,
        ExpressionAttributeValues: marshall({
          ':status': 'failed',
          ':error': error.message
        })
      });

      await dynamoClient.send(updateCommand);
    } catch (updateError) {
      console.error('❌ Failed to update report status:', updateError);
    }

    return {
      success: false,
      error: error.message
    };
  }
}

module.exports = {
  processTranscriptAnalytics
};
