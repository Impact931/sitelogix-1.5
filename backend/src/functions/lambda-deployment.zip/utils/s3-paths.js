"use strict";
/**
 * S3 Path Utilities for SiteLogix
 *
 * All paths use the SiteLogix root folder structure:
 * SiteLogix/projects/{projectId}/...
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildS3HttpsUrl = exports.buildS3Url = exports.isValidSiteLogixPath = exports.parseS3Path = exports.buildSystemPath = exports.buildArchivePath = exports.buildManagerDataPath = exports.buildProjectMetadataPath = exports.buildAnalysisPath = exports.buildParsedDataPath = exports.buildTranscriptPath = exports.buildAudioPath = exports.parseDateComponents = void 0;
/**
 * Parse a date string into year/month/day components
 */
var parseDateComponents = function (dateString) {
    var date = new Date(dateString);
    return {
        year: String(date.getFullYear()),
        month: String(date.getMonth() + 1).padStart(2, '0'),
        day: String(date.getDate()).padStart(2, '0')
    };
};
exports.parseDateComponents = parseDateComponents;
/**
 * Build S3 path for audio file
 * Format: SITELOGIX/projects/{projectId}/reports/{YYYY}/{MM}/{DD}/{reportId}/audio.webm
 */
var buildAudioPath = function (projectId, reportDate, reportId, format) {
    if (format === void 0) { format = 'webm'; }
    var _a = (0, exports.parseDateComponents)(reportDate), year = _a.year, month = _a.month, day = _a.day;
    return "SITELOGIX/projects/".concat(projectId, "/reports/").concat(year, "/").concat(month, "/").concat(day, "/").concat(reportId, "/audio.").concat(format);
};
exports.buildAudioPath = buildAudioPath;
/**
 * Build S3 path for transcript file (JSON)
 * Format: SITELOGIX/projects/{projectId}/reports/{YYYY}/{MM}/{DD}/{reportId}/transcript.json
 */
var buildTranscriptPath = function (projectId, reportDate, reportId) {
    var _a = (0, exports.parseDateComponents)(reportDate), year = _a.year, month = _a.month, day = _a.day;
    return "SITELOGIX/projects/".concat(projectId, "/reports/").concat(year, "/").concat(month, "/").concat(day, "/").concat(reportId, "/transcript.json");
};
exports.buildTranscriptPath = buildTranscriptPath;
/**
 * Build S3 path for parsed data (JSON)
 * Format: SITELOGIX/projects/{projectId}/reports/{YYYY}/{MM}/{DD}/{reportId}/parsed-data.json
 */
var buildParsedDataPath = function (projectId, reportDate, reportId) {
    var _a = (0, exports.parseDateComponents)(reportDate), year = _a.year, month = _a.month, day = _a.day;
    return "SITELOGIX/projects/".concat(projectId, "/reports/").concat(year, "/").concat(month, "/").concat(day, "/").concat(reportId, "/parsed-data.json");
};
exports.buildParsedDataPath = buildParsedDataPath;
/**
 * Build S3 path for AI analysis results
 * Format: SITELOGIX/projects/{projectId}/reports/{YYYY}/{MM}/{DD}/{reportId}/analysis-{type}.json
 */
var buildAnalysisPath = function (projectId, reportDate, reportId, analysisType) {
    var _a = (0, exports.parseDateComponents)(reportDate), year = _a.year, month = _a.month, day = _a.day;
    return "SITELOGIX/projects/".concat(projectId, "/reports/").concat(year, "/").concat(month, "/").concat(day, "/").concat(reportId, "/analysis-").concat(analysisType, ".json");
};
exports.buildAnalysisPath = buildAnalysisPath;
/**
 * Build S3 path for project metadata
 * Format: SITELOGIX/projects/{projectId}/metadata/{filename}
 */
var buildProjectMetadataPath = function (projectId, filename) {
    return "SITELOGIX/projects/".concat(projectId, "/metadata/").concat(filename);
};
exports.buildProjectMetadataPath = buildProjectMetadataPath;
/**
 * Build S3 path for manager-specific data
 * Format: SITELOGIX/managers/{managerId}/{type}/{filename}
 */
var buildManagerDataPath = function (managerId, type, filename) {
    return "SITELOGIX/managers/".concat(managerId, "/").concat(type, "/").concat(filename);
};
exports.buildManagerDataPath = buildManagerDataPath;
/**
 * Build S3 path for archive
 * Format: SITELOGIX/projects/{projectId}/archive/{YYYY}/{reportId}.{format}
 */
var buildArchivePath = function (projectId, reportDate, reportId, format) {
    if (format === void 0) { format = 'webm'; }
    var year = (0, exports.parseDateComponents)(reportDate).year;
    return "SITELOGIX/projects/".concat(projectId, "/archive/").concat(year, "/").concat(reportId, ".").concat(format);
};
exports.buildArchivePath = buildArchivePath;
/**
 * Build S3 path for system config files
 * Format: SITELOGIX/system/{type}/{filename}
 */
var buildSystemPath = function (type, filename) {
    return "SITELOGIX/system/".concat(type, "/").concat(filename);
};
exports.buildSystemPath = buildSystemPath;
/**
 * Extract components from an existing S3 path
 */
var parseS3Path = function (s3Path) {
    var parts = s3Path.split('/');
    var result = {};
    // Check if it's a project path
    var projectIndex = parts.indexOf('projects');
    if (projectIndex !== -1 && parts[projectIndex + 1]) {
        result.projectId = parts[projectIndex + 1];
    }
    // Check if it's a manager path
    var managerIndex = parts.indexOf('managers');
    if (managerIndex !== -1 && parts[managerIndex + 1]) {
        result.managerId = parts[managerIndex + 1];
    }
    // Extract date components if present
    var datePattern = /(\d{4})\/(\d{2})\/(\d{2})/;
    var dateMatch = s3Path.match(datePattern);
    if (dateMatch) {
        result.year = dateMatch[1];
        result.month = dateMatch[2];
        result.day = dateMatch[3];
    }
    // Extract report ID from filename
    var reportIdPattern = /(rpt_\d{8}_[a-z0-9]+_[a-z0-9]+)/;
    var reportMatch = s3Path.match(reportIdPattern);
    if (reportMatch) {
        result.reportId = reportMatch[1];
    }
    // Determine type (audio, transcripts, parsed-data, etc.)
    if (s3Path.includes('/audio/'))
        result.type = 'audio';
    else if (s3Path.includes('/transcripts/'))
        result.type = 'transcripts';
    else if (s3Path.includes('/parsed-data/'))
        result.type = 'parsed-data';
    else if (s3Path.includes('/ai-analysis/'))
        result.type = 'ai-analysis';
    else if (s3Path.includes('/archive/'))
        result.type = 'archive';
    return result;
};
exports.parseS3Path = parseS3Path;
/**
 * Validate S3 path follows SiteLogix structure
 */
var isValidSiteLogixPath = function (s3Path) {
    // Must start with SITELOGIX/
    if (!s3Path.startsWith('SITELOGIX/')) {
        return false;
    }
    // Must have at least one category (projects, managers, system)
    var validCategories = ['projects', 'managers', 'system'];
    var hasValidCategory = validCategories.some(function (cat) { return s3Path.includes("SITELOGIX/".concat(cat, "/")); });
    return hasValidCategory;
};
exports.isValidSiteLogixPath = isValidSiteLogixPath;
/**
 * Build full S3 URL
 */
var buildS3Url = function (bucket, key) {
    return "s3://".concat(bucket, "/").concat(key);
};
exports.buildS3Url = buildS3Url;
/**
 * Build HTTPS URL for S3 object
 */
var buildS3HttpsUrl = function (bucket, key, region) {
    if (region === void 0) { region = 'us-east-1'; }
    return "https://".concat(bucket, ".s3.").concat(region, ".amazonaws.com/").concat(encodeURIComponent(key));
};
exports.buildS3HttpsUrl = buildS3HttpsUrl;
// Export all utilities
exports.default = {
    parseDateComponents: exports.parseDateComponents,
    buildAudioPath: exports.buildAudioPath,
    buildTranscriptPath: exports.buildTranscriptPath,
    buildParsedDataPath: exports.buildParsedDataPath,
    buildAnalysisPath: exports.buildAnalysisPath,
    buildProjectMetadataPath: exports.buildProjectMetadataPath,
    buildManagerDataPath: exports.buildManagerDataPath,
    buildArchivePath: exports.buildArchivePath,
    buildSystemPath: exports.buildSystemPath,
    parseS3Path: exports.parseS3Path,
    isValidSiteLogixPath: exports.isValidSiteLogixPath,
    buildS3Url: exports.buildS3Url,
    buildS3HttpsUrl: exports.buildS3HttpsUrl
};
